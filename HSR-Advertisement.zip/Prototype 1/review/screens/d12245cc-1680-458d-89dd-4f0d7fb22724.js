var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1440" deviceHeight="900">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1440" height="900">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1665680441041.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 1" width="1440" height="900">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1665680441041.css" />\
      <div class="freeLayout">\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="306.5px" datasizeheight="222.0px" dataX="1134.5" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/975ab4e1-a8d6-4025-b2de-5fc2625acb66.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="1034.0px" datasizeheight="728.2px" dataX="0.0" dataY="171.8"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/70a0c25b-f8e3-428f-9036-5c23087e4ff2.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Type something here..."   datasizewidth="163.6px" datasizeheight="18.0px" dataX="76.0" dataY="193.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Type something here...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="413.9" dataY="121.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer commentable non-processed" customid="About UsWe have experts t"   datasizewidth="428.0px" datasizeheight="691.0px" dataX="1013.0" dataY="211.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">About Us<br /></span><span id="rtr-s-Paragraph_3_1">We have experts to spot almost all vehicle problems! General Service, Running Repair, Accident Repair, Body Repair, Painting &amp; Value Added Services.<br /></span><span id="rtr-s-Paragraph_3_2"><br /><br /></span><span id="rtr-s-Paragraph_3_3">Contact Us<br /></span><span id="rtr-s-Paragraph_3_4">23 Ram street,Chennai Bypass Rd,Chennai-631209<br />Tamil Nadu <br />India<br />Mobile no:983937322<br />Mail id:hsr@gmail.com<br />www.hsr.com<br /></span><span id="rtr-s-Paragraph_3_5"><br /><br />Book Your Car Service now</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="500.5px" datasizeheight="264.5px" dataX="634.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/423b43e6-1377-47f4-bdb4-ce5d2472329b.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_4" class="richtext manualfit firer commentable non-processed" customid="HSR Motors &nbsp;car dealershi"   datasizewidth="510.7px" datasizeheight="252.0px" dataX="157.8" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">HSR Motors <br /> car <br />dealership</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Click"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="1162.5" dataY="820.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Click</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="170.8px" datasizeheight="192.8px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f87c79dd-a7b9-40b2-a8f9-f18bac1012f6.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_5" class="richtext manualfit firer commentable non-processed" customid="WE AREHERE TO HELP" rotationdeg="317.0"  datasizewidth="227.4px" datasizeheight="105.0px" dataX="780.4" dataY="696.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">WE ARE<br /></span><span id="rtr-s-Paragraph_5_1">HERE TO HELP</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;